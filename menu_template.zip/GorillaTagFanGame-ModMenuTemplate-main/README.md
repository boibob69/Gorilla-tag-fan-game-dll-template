# GorillaTagFanGame-ModMenuTemplate
## Credits to Lars & ColossusYTTV for the GUI/HUD Template, this is just my modified version meant for fan-games & easier use.

**This is a Menu Template that you can easily modify to make a mod menu in Gorilla Tag Fan Games.**
